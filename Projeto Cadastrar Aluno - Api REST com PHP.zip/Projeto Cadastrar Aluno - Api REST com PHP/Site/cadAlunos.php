<h3>Cadastro de Alunos</h3>
<hr>

<form>
	R.G.M: 	<input type="text" name="nome"><br>
	NOME: 	<input type="text" name="nome"><br>
	E-MAIL: <input type="text" name="nome"><br>
	<input type="submit" value="Cadastrar">
</form>