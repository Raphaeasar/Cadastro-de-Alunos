<!DOCTYPE html>
<html>
	<head>
		<title>Meu Layout</title>
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="estilo.css">
	</head>
	<body>
		<div id="container">
			<div id="topo">
				<h1>Sistemas de Alunos</h1>
			</div>
			<div id="lateral">
				<a href="index.php?pag=lista">Lista dos Alunos</a><br>
				<a href="index.php?pag=cad">Cadastro de Alunos</a><br>
			</div>
			<div id="conteudo">
			<?php
			if	(isset($_GET['pag'])){
				$pagina = $_GET['pag'];
				
				if($pagina == 'lista'){
					
					include('listaAlunos.php');
					
				}else if($pagina == 'cad'){
					
					include('cadAlunos.php');
					
				}
			}else{
				
				include('principal.php');
				
			}
			
			?>
			</div>
			<div id="rodape">
				<b>Site desenvolvido por Chimbinha</b>
			</div>
		</div>
	</body>
</html>