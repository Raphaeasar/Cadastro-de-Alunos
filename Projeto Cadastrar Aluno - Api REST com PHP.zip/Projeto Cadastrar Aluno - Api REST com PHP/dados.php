<?php
//ARRAY MULTIFUNCIONAL

$dados[0]['rgm'] = 12345678;
$dados[0]['nome'] = 'Fulano de tal';
$dados[0]['email'] = 'fulano@tal.com';

$dados[1]['rgm'] = 13579111;
$dados[1]['nome'] = 'Ciclano do Tio';
$dados[1]['email'] = 'ciclano@tio.org';

$dados[2]['rgm'] = 24681012;
$dados[2]['nome'] = 'Beltrano do Palco';
$dados[2]['email'] = 'beltrano@palco.net';



?>