<!DOCTYPE html>
<html>
	<head>
		<title>Tabelas HTML com PHP</title>
		<meta charset="UTF-8">
	</head>
	<body>
		<table border="1">
			<tr>
				<th>R.G.M</th>
				<th>NOME</th>
				<th>E-MAIL</th>
			</tr>
			<?php include('dados.php'); ?>
			
			<?php foreach ($dados as $linha) { ?>
			
			<tr>
				<td><?php echo $linha['rgm']; ?></td>
				<td><?php echo $linha['nome']; ?> </td>
				<td><?php echo $linha['email']; ?> </td>
			</tr>
			<?php } ?>
		</table>							
	</body>
</html>
	
	
